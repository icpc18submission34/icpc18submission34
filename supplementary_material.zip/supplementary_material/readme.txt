# CONTENTS

==========
r-files:
==========
all data needed to rerun the experiments
- posts.csv contains the postid, question category (reason), title, body, phrase (how), pos-title, pos-body, pos-phrase of the 500 posts
- validation_posts.csv contains the postid, question category (reason), title, body, phrase (how), pos-title, pos-body, pos-phrase of the 100 posts that were not used for training and testing before
- all_combinations.R: to run RF and SVM in 82x2 configurations
- best_combination.R: (to tune RF) and run RF with the best settings 
- evaluation.R: to run the evaluation with 100 unseen posts

To rerun the r-scripts, please make sure that the following directories exist in your R working directory:
~/res/20 
~/res/100
~/sum/20

To start the scripts, uncomment the start function at the end of the file. 

==========
replication:
==========
all data to replicate our results
- results_before_discussion_485.csv: the 485 labeled posts before the discussion (without the 50 posts that were labeled together)
- the results of the experiments: 
-> res/20: results of the 20 runs
-> res/100: results of the 100 runs
-> eval: data obtained by the validation of 100 runs with 100 unseen posts
