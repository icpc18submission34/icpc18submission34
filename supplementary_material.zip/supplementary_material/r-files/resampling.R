library(unbalanced)
library(caret)
library(e1071)
library(rpart)
library(RTextTools)
library(tm)
library(DMwR)
set.seed(1234)

resampling_binary <- function(train.DTM){
  amtTrue=sum(train.DTM$label==TRUE)
  amtFalse=sum(train.DTM$label==FALSE)
  
  po = 200
  smoted.DTM = SMOTE(label ~ ., train.DTM, perc.over = po, perc.under =100) 
  smoted.DTM.only = smoted.DTM[!rownames(smoted.DTM) %in% rownames(train.DTM), ]
  
  if(amtTrue-amtFalse > 0){ 
    # we need more false examples
    smoted.DTM.only = smoted.DTM.only[smoted.DTM.only$label==FALSE,]
    while(dim(smoted.DTM.only)[1] < amtTrue-amtFalse){
      po = po*2
      smoted.DTM = SMOTE(label ~ ., train.DTM, perc.over = po, perc.under =100) 
      smoted.DTM.only = smoted.DTM[!rownames(smoted.DTM) %in% rownames(train.DTM), ]
      smoted.DTM.only = smoted.DTM.only[smoted.DTM.only$label==FALSE,]
    }
    
    smoted.sample=sample(1:dim(smoted.DTM.only)[1], amtTrue-amtFalse)
    train.DTM = rbind(train.DTM, smoted.DTM.only[smoted.sample,])
    
  }else{
    # we need more true examples
    smoted.DTM.only = smoted.DTM.only[smoted.DTM.only$label==TRUE,]
    while(dim(smoted.DTM.only)[1] < amtFalse-amtTrue){
      po = po*2
      smoted.DTM = SMOTE(label ~ ., train.DTM, perc.over = po, perc.under =100) 
      smoted.DTM.only = smoted.DTM[!rownames(smoted.DTM) %in% rownames(train.DTM), ]
      smoted.DTM.only = smoted.DTM.only[smoted.DTM.only$label==TRUE,]
    }
    smoted.sample=sample(1:dim(smoted.DTM.only)[1], amtFalse-amtTrue)
    train.DTM = rbind(train.DTM, smoted.DTM.only[smoted.sample,])
  }
  
  table(train.DTM$label)
  prop.table(table(train.DTM$label))
  return(train.DTM)
}


resampling_multi <- function(train.DTM){
  
# print("TODO implement smote  multi")

  tbl = data.frame(table(train.DTM$label))
  colnames(tbl)=c("label", "freq")
  lbl_max = tbl[tbl$freq==max(tbl$freq),]
  amt_max = max(tbl$freq)
  
  orig.DTM = train.DTM
  po = 200
  for(lbl in tbl$label[-(which(tbl$freq==amt_max))]){
    tmp.DTM= orig.DTM
    
    amt_lbl = tbl[tbl$label==lbl,]$freq
    # make binary for smote
    tmp.DTM$bin_lbl = F
    tmp.DTM[which(tmp.DTM$label==lbl),]$bin_lbl=T
    tmp.DTM$bin_lbl = as.factor(tmp.DTM$bin_lbl)
    tmp.DTM$label=NULL
    smoted.DTM.only = data.frame()
    while(dim(smoted.DTM.only)[1] < amt_max-amt_lbl){
      smoted.DTM = SMOTE(bin_lbl ~ ., tmp.DTM, perc.over = po, perc.under =100) 
      smoted.DTM.only = smoted.DTM[!rownames(smoted.DTM) %in% rownames(tmp.DTM), ]
      smoted.DTM.only = smoted.DTM.only[smoted.DTM.only$bin_lbl==TRUE,]
      po = po*2
    }
    smoted.sample=sample(1:dim(smoted.DTM.only)[1], amt_max - amt_lbl)
    smoted.sample.data = smoted.DTM.only[smoted.sample,]
    smoted.sample.data$label=lbl
    smoted.sample.data$bin_lbl=NULL
    orig.DTM = rbind(orig.DTM, smoted.sample.data)
    
  } 
    
   return(orig.DTM)

}
