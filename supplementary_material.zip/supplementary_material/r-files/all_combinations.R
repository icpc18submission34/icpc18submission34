library(text2vec)
library(data.table)
library(tokenizers)
library(randomForest)
library(caret)
library(pROC)
library(ROCR)
library(e1071)
library(SparseM)
library(doMC)
library(foreach)
library(plyr)
library(psych)

setwd("path/to/here")

source("resampling.R")
source("rf.R")
source("svm.R")
source("preprocessor.R")


# SETTINGS
registerDoMC(4) # define number of cores to use
filename="posts.csv"
MLalgorithm="RF" # toggle RF - random forest, SVM - support vector machine


# general settings - do not change for replication
lNgram <<- c(1,2,3)
lSw<<-c("none", "custom")
lLabel<<-c("sl")
lTune<<-c(F)
lPrune<<-c(T,F)
lResampling<<-c("none", "smote")
sources=c("all") # choose between title, body, and both

tune<-F
resetTune=F
randomRuns<-20
distr<-0.9 # distribution of training and test set for stratified random sampling
do_imps<-F # toggle whether to calulate the Mean Decrease of Gini index for RF


start <- function(){

  if(MLalgorithm=="RF"){
  # RF - BINARY - FULL
   print(">> RF - BINARY: txt, pos, combi ")
   results.rf_txt_bin = run_mla("RF", "txt", "full", "res/20/results.rf_txt_bin")
   results.rf_pos_bin = run_mla("RF", "pos", "full", "res/20/results.rf_pos_bin")
   results.rf_combi_bin=run_mla("RF", "combi","full", "res/20/results.rf_combi_bin")
    
   # RF - BINARY - PHRASES (short)
   print(">> RF - BINARY: txt, pos, combi ")
   results.rf_txt_bin_short = run_mla("RF", "txt", "short", "res/20/results.rf_txt_bin_short")
   results.rf_pos_bin_short = run_mla("RF", "pos", "short", "res/20/results.rf_pos_bin_short")
   results.rf_combi_bin_short=run_mla("RF", "combi","short", "res/20/results.rf_combi_bin_short")
  
   }else if(MLalgorithm=="SVM"){
     
     # SVM - BINARY - FULL
     print(">> SVM - BINARY: txt, pos, combi ")
     results.svm_txt_bin = run_mla("SVM","txt", "full", "res/20/results.svm_txt_bin")
     results.svm_pos_bin = run_mla("SVM", "pos", "full","res/20/results.svm_pos_bin")
     results.svm_combi_bin=run_mla("SVM", "combi", "full","res/20/results.svm_combi_bin")
      
     # # SVM - BINARY - PHRASES (short)
     print(">> SVM - BINARY: txt, pos, combi ")
     results.svm_txt_bin_short= run_mla("SVM","txt", "short", "res/20/results.svm_txt_bin_short")
     results.svm_pos_bin_short = run_mla("SVM", "pos", "short","res/20/results.svm_pos_bin_short")
     results.svm_combi_bin_short=run_mla("SVM", "combi", "short","res/20/results.svm_combi_bin_short")
  }else{
   print("MLalgorithm argument is not valid")
 }

}

run_mla <- function(MLA, type,how, fn){
  
    for(source in sources){
  
    filename = paste(fn, "_",source,  ".csv", sep="")
    if(file.exists(filename)){
      file.remove(filename)
    }
    if(tune){
      filename = paste("tune_settings_",MLA,"_", type,".csv", sep="")
    }
    
    rf = data.frame()
    header = ""
    for(ngram in lNgram){
      for(sw in lSw){
        for(label in lLabel){
          for(tune in lTune){
            for(prune in lPrune){
              for(resample in lResampling){
                
                if(type=="combi"){
                  for(mgram in lNgram){
                 # for(mgram in lMgram){
                      print(paste("> BINARY > source= ", source, ", type= ", type, ", how= ", how, ", ngram_txt= ", ngram, ", ngram_pos= ", mgram, ", sw= ", sw, ", label= ", label, ", tune= ", tune, ", prune= ", prune, ", resample= ", resample, sep=""))
                      if(prune==T & (ngram==3 |mgram==3)){
                        print("skip -> pruning and ngram=3")
                      }else if(sw=="custom" & type=="pos"){
                        print("skip -> stowpords and pos")
                      }else{
                        res = apply_mla_binary(MLA, source, type, how, list("txt"=ngram, "pos"=mgram), sw, label, tune, prune, resample)
                        res = cbind("source"=source, "type"=type, "how"=how, res)
                        rf = rbind.fill(rf, res )
                        
                        write.table(res, filename, append=TRUE, sep=",", row.names=F, col.names = F)
                        header = names(res)
                      }
                 }
                }else{
           
                    print(paste("> BINARY > source= ", source, ", type= ", type, ", how= ", how, ", ngram= ", ngram, ", sw= ", sw, ", label= ", label, ", tune= ", tune, ", prune= ", prune, ", resample= ", resample, sep=""))
                    if(prune==T & ngram==3){
                      print("skip -> pruning and ngram=3")
                    }else if(sw==T & type=="pos"){
                      print("skip -> stowpords and pos")
                    }else{
                      res = apply_mla_binary(MLA, source, type, how, ngram, sw, label, tune, prune,resample)
                      res = cbind("source"=source, "type"=type, "how"=how, res)
                      rf = rbind.fill(rf,res )
                      write.table(res, filename, append=TRUE, sep=",", row.names=F, col.names = F)
                      header = names(res)
                    }
                 
                }}}}}}}
    add_header(t(header), filename, sep=",")
 }
  
  return(rf)
}

add_header <- function(header, filename, sep){
  
  if(do_imps || tune){
    print("--> does not work with rows having a different amount of colums")
  } else if(file.exists(filename)){
    ## read the existing content
    temp.df <- fread(filename, strip.white = )

    ## append in front
    df <- rbind(header, temp.df)
    
    ## write back the whole data frame
    fwrite(df, filename, append=FALSE, sep=sep, col.names=F)
  }
  
}

get_metrics <- function(predictions, reason_, probs, binary=T){

  positive="TRUE"
 
  matrix_t = confusionMatrix(predictions, reason_, "TRUE")
  #print(matrix_t$table)
  
  conf=matrix_t$table
  prec_t = matrix_t$byClass[5]
  rec_t = matrix_t$byClass[6]
  
  if(is.na(prec_t)){
    prec_t=0
  }
  if(is.na(rec_t)){
    rec_t=0
  }
  f1_t = matrix_t$byClass[7]
  
  if(prec_t==0 & rec_t==0){
    f1_t = 0
  }
  
  matrix_f = confusionMatrix(predictions, reason_, "FALSE")
  prec_f = matrix_f$byClass[5]
  rec_f = matrix_f$byClass[6]
  
  if(is.na(prec_f)){
    prec_f=0
  }
  if(is.na(rec_f)){
    rec_f=0
  }
  f1_f = matrix_f$byClass[7] #2*prec_f*rec_f/(prec_f+rec_f)
  
  if(prec_f==0 & rec_f==0){
    f1_f = 0
  }
  
  anz_f = table(reason_)[1]
  anz_t = table(reason_)[2]
    
  prec_avg  = (prec_t *anz_t  + prec_f * anz_f ) / (anz_t+anz_f)
  rec_avg  = (rec_t *anz_t  + rec_f * anz_f ) / (anz_t+anz_f)
  f_avg  = (f1_t *anz_t  + f1_f * anz_f ) / (anz_t+anz_f)
    
  acc = matrix_t$overall[1]
  auc <- roc(reason_, probs[,2], levels=c("TRUE", "FALSE"))$auc
    
  metrics=data.frame(acc=acc,prec_t=prec_t,rec_t=rec_t,f_t=f1_t,prec_f=prec_f,rec_f=rec_f,f_f=f1_f,prec_avg=prec_avg, rec_avg=rec_avg, f_avg=f_avg,auc=auc)
  rownames(metrics)=""

  return(list("metrics"=metrics, "conf"=conf))
}

apply_mla_binary <- function(MLA, source, type,how, ngrams, sw, label, tune, prune, resample){
  binary = T
  tmpResults = data.frame()
  #for(i in seq(1:randomRuns)){ # comment in for debugging or when running without parallelization
  tmpResults = foreach(i=1:randomRuns,.combine = rbind) %dopar% {  
   
    retList = data.frame()
    impsList = data.frame()
    data=preprocess_data(source, type, how, label, binary)
    names_ = names(table(data$reason))

    for( name in names_){
      print(name)
      data_set = apply_stratified_sampling(data,name, binary, how)
      
      train = data_set$train
      test = data_set$test 
      
      # make test set unique
      test_unique=data.frame()
      for(id in unique(test$id)){
        test_unique = rbind(test_unique,test[test$id == id,][1,])
      }
      test = test_unique
      
      if(type=="combi"){
        data_ = get_train_test_dtms_combi(train, test, sw, ngrams, prune, resample, binary, how)
      } else{
        if(how=="short"){
          data_ = get_train_test_dtms(train, train$txt, test, test$full, sw, ngrams, prune, resample, binary)
        } else{
          data_ = get_train_test_dtms(train, train$txt, test, test$txt, sw, ngrams, prune, resample, binary)
        }
      }
      
      
      if(MLA=="RF"){
        rf.res = apply_random_forest(data_, name,i, ngrams, sw, label, tune, prune, resample,binary, source, type,how)
        rlist = rf.res$res
        conf = rf.res$conf
        if(do_imps==T){
          impsList = rbind.fill(impsList, rf.res$imps)
        }
        } else if (MLA =="SVM"){
        svm.res = apply_svm(data_, name,i, ngrams, sw, label, tune, prune, resample,binary, source, type,how)
        rlist = svm.res$res
        conf = svm.res$conf
      }
      rlist = cbind(rlist, "TN"=conf[1], "FP" = conf[2], "FN" = conf[3], "TP" = conf[4])
      retList = rbind(retList,rlist)
     
      }
    
    if(do_imps==T){
      retList = cbind(retList, impsList)
    }
    
    #return(retList) # comment in for debugging or when running without parallelization
    tmpResults = rbind.fill(tmpResults, retList)
  }
  return(tmpResults)
}

#start()