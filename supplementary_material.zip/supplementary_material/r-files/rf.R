
apply_random_forest <- function(data, name, run, ngrams, sw, label, tune, prune, resample, binary = T, source, type,how, ntree=500){
  if(is.null(ntree)){ # dirty hack
    ntree=500
  }
  test = data$test
  train = data$train
  dtm_test = data$dtm_test
  dtm_train = data$dtm_train
  train.label = dtm_train$label
  test.label = data$test$reason
  dtm_train$label=NULL
  dtm_test$label=NULL
  
  
  setting=list("run"=run, "reason" = name,"ngrams"=ngrams, "sw"=sw, "label"=label, "tune"=tune, "prune"=prune, "resample"=resample)
  
  
  # tuning
  if(tune){
    if(how=="short"){
       tuned.rf <-  tune.randomForest(x=as.matrix(dtm_train), y=train.label, validation.x=as.matrix(dtm_test), validation.y=test.label, importance=T, ntree = seq(50,600,50), tunecontrol = tune.control(sampling="fix", fix=0.8, nrepeat=5))
       reason.rf <-  tuned.rf$best.model
    } else{
      tuned.rf <-  tune.randomForest(x=as.matrix(dtm_train), y=train.label, importance=T, ntree = seq(50,600,50), tunecontrol = tune.control(sampling="cross", cross=5, nrepeat=10))
      reason.rf <-  tuned.rf$best.model
    }
    
  return(list("res" = cbind(setting, tuned.rf$best.parameters), "conf"=c("-","-","-","-"))) # necessary??
    
    
  }else{
    
    ntree = ntree
    reason.rf=randomForest(x=dtm_train, y=train.label, importance=T,ntree=ntree)
    
    predictions=predict(reason.rf, dtm_test, type="response")
    test$predictions=predictions
    probs=predict(reason.rf, dtm_test, type="prob")
    
    #metrics
    mm = get_metrics(predictions, test$reason, probs)
    metrics = mm$metrics
    conf = mm$conf
    
    # importances
    if(do_imps==T){
      imps=importance(reason.rf) #ONLY RF
      imps=as.data.frame(t(imps[,"MeanDecreaseGini"])) #MeanDeceaseAccuracy  #ONLY RF
      return(list("res" = cbind(setting, metrics), "conf"=conf, "imps"=imps))
    }else{
      return(list("res" = cbind(setting, metrics), "conf"=conf))
    }
  }
  
 
 
}


