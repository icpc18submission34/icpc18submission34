
library(text2vec)
library(data.table)
library(tokenizers)
library(randomForest)
library(caret)
library(pROC)
library(ROCR)
library(e1071)
library(SparseM)
library(doMC)
library(foreach)
registerDoMC(4)
library(plyr)
library(psych)
setwd("path/to/here")

source("preprocessor.R")
source("resampling.R")


filename="posts.csv"
source="all"
type="how"
label="sl"
binary=T
ML="RF"
runs=100

start_evaluation <- function(){
 
  # change
  eval_change=evaluation(runs, 1)
  # usage
  eval_usage=evaluation(runs, 2)
  # conceptual
  eval_conceptual=evaluation(runs, 3)
  # discprepancy
  eval_discrepancye=evaluation(runs, 4)
  # documents
  eval_documents=evaluation(runs, 5)
  # errors
  eval_errors=evaluation(runs, 6)
  # review
  eval_review=evaluation(runs, 7)
}


evaluation <- function(runs, cat){

  models = list()
  df_results = data.frame()
  df_results = foreach(i=seq(1,runs),.combine = rbind.fill) %dopar% {  
    
    model = get_model_per_category(cat)
    res =  get_predictions_per_model(model)
    if(i%%10==0){
      print(i)
    }
    return(res)
    
  }
  
  if(cat==1){
    #change
    df_results$cat="change"
    fwrite(df_results, "data/eval_change.csv")
    print("finished with change")
  }else if (cat==2){
    #usage
    df_results$cat="usage"
    fwrite(df_results, "data/eval_usage.csv")
    print("finished with usage")
    
  }else if (cat==3){
    #conceptual
    df_results$cat="conceptual"
    fwrite(df_results, "data/eval_conceptual.csv")
    print("finished with conceptual")
    
  }else if (cat==4){
    #discrepancy
    df_results$cat="discrepancy"
    fwrite(df_results, "data/eval_discrepancy.csv")
    print("finished with discrepancy")
    
  }else if (cat==5){
    #documents
    df_results$cat="documents"
    fwrite(df_results, "data/eval_documents.csv")
    print("finished with documents")
    
  }else if (cat==6){
    #error
    df_results$cat="error"
    fwrite(df_results, "data/eval_error.csv")
    print("finished with error")
    
  }else if (cat==7){
   # review
    df_results$cat="review"
    fwrite(df_results, "data/eval_review.csv")
    print("finished with review")
    
  }else{
   print("ERROR cat does not exist") 
  }
 
  return(df_results)
}





get_predictions_per_model <-function (model_cat){
  model = model_cat$model
  data = model_cat$data
  test = data$test
  
  predictions=predict(model, data$dtm_test, type="response")
  test$predictions=predictions
  probs=predict(model, data$dtm_test, type="prob")
  
  #metrics
  matrix_t = confusionMatrix(predictions, test$reason, "TRUE")
  conf = matrix_t$table
  prec_t = matrix_t$byClass[5]
  rec_t = matrix_t$byClass[6]
  
  if(is.na(prec_t)){
    prec_t=0
  }
  if(is.na(rec_t)){
    rec_t=0
  }
  f1_t = matrix_t$byClass[7]
  
  if(prec_t==0 & rec_t==0){
    f1_t = 0
  }
  
  
  matrix_f = confusionMatrix(predictions, test$reason, "FALSE")
  prec_f = matrix_f$byClass[5]
  rec_f = matrix_f$byClass[6]
  
  if(is.na(prec_f)){
    prec_f=0
  }
  if(is.na(rec_f)){
    rec_f=0
  }
  f1_f = matrix_f$byClass[7] #2*prec_f*rec_f/(prec_f+rec_f)
  
  if(prec_f==0 & rec_f==0){
    f1_f = 0
  }
  
  anz_f = table(test$reason)[1]
  anz_t = table(test$reason)[2]
  
 
  
  prec_avg  = (prec_t *anz_t  + prec_f * anz_f ) / (anz_t+anz_f)
  rec_avg  = (rec_t *anz_t  + rec_f * anz_f ) / (anz_t+anz_f)
  f_avg  = (f1_t *anz_t  + f1_f * anz_f ) / (anz_t+anz_f)
  
  acc = matrix_f$overall[1]
  auc <- roc(test$reason, probs[,2], levels=c("TRUE", "FALSE"))$auc
  

  # importances
  imps=importance(model) #ONLY RF
  imps=as.data.frame(t(imps[,"MeanDecreaseGini"])) #MeanDeceaseAccuracy  #ONLY RF
 # print( imps[,imps>5])
  
  return(data.frame(acc=acc,prec_t=prec_t,rec_t=rec_t,f_t=f1_t,prec_f=prec_f,rec_f=rec_f,f_f=f1_f,prec_avg=prec_avg, rec_avg=rec_avg, f_avg=f_avg,auc=auc, TN=conf[1], FP = conf[2], FN = conf[3], TP = conf[4]))
  
}


get_model_per_category <- function(idx){
  
  settings_RF =fread("settings_RF.csv")
  cat = settings_RF[idx,]
  #print(cat$reason)
  if(cat$type=="combi"){
    ret = apply_mla_train(ML, cat$source, cat$type, cat$how, list("txt"=cat$ngrams.txt, "pos"=cat$ngrams.pos), cat$sw, cat$label,cat$prune, cat$resample, cat$reason)
    #data_val  = get_validation_data(ML, cat$source, cat$type, cat$how, list("txt"=cat$ngrams.txt, "pos"=cat$ngrams.pos), cat$sw, cat$label,cat$prune, cat$resample, cat$reason)
    
  } else{
    ret = apply_mla_train(ML, cat$source, cat$type, cat$how, cat$ngrams,cat$sw, cat$label, cat$prune, cat$resample, cat$reason)
  }   
  
  return(list("model"=ret$model,"data"=ret$data))
}

apply_mla_train <-function(MLA="RF", source, type, how, ngrams,sw,label,prune,resample,category,ntree=500){
  #print(paste("ntrees=",ntree,sep=""))
  
  binary=T
  train=preprocess_data(source, type, how, label, binary)
  train =  return_binary(train, category)
  
  test = preprocess_data(source, type, "full", label, binary,T)
  test_dupl =  return_binary(test,category)
  test = data.frame()
  #id=26393311
  for(id in unique(test_dupl$id)){
    test = rbind(test,test_dupl[test_dupl$id == id,][1,])
  }
  

  # data sanity check
  # apply_data_sanity_check(test, train)
    if(type=="combi"){
      data_ = get_train_test_dtms_combi(train, test, sw, ngrams, prune, resample, binary, how, T)
    } else{
      if(how=="short"){
        data_ = get_train_test_dtms(train, train$txt, test, test$txt, sw, ngrams, prune, resample, binary)
      } else{
        data_ = get_train_test_dtms(train, train$txt, test, test$txt, sw, ngrams, prune, resample, binary)
      }
    }
      
   model=0
   if(MLA=="RF"){
       # TRAIN
      dtm_train = data_$dtm_train
      train.label = data_$dtm_train$label
      dtm_train$label=NULL
  
      model=randomForest(x=dtm_train, y=train.label, importance=T,ntree=ntree)
      
    } else{
        print("not implemented yet")
    }
  
  return(list("model"=model,"data"=data_))
}


return_binary <- function(data_in, category){
  # BINARY
  data = data_in
  data$cat = F
  data[data$reason==category,]$cat=T
  data$reason=data$cat
  data$cat=NULL
  cat = data[data$reason ==T,]
  notCat = data[!data$id %in% cat$id, ]
  data_out = rbind(cat, notCat)
  return(data_out)
}
#start_evaluation()
