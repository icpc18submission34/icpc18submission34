#source("resampling.R") 
preprocess_data <- function(source, type, how, label, binary, validation=F){
  
  if(validation==T){
    df=read.table("validation_posts.csv", sep=",", quote="\"", col.names= c("id", "reason", "title", "body", "how", "title_pos", "body_pos", "how_pos"), stringsAsFactors=FALSE, header=TRUE)
    
  }else{
    df=read.table(filename, sep=";", quote="\"", col.names= c("id", "reason", "title", "body", "how", "title_pos", "body_pos", "how_pos"), stringsAsFactors=FALSE, header=TRUE)
  }
  
  
  # source
  if(source=="all"){
    df$txt = paste(df$title , df$body, sep=" ")
    df$pos = paste(df$title_pos , df$body_pos, sep=" ")
    df$title=NULL
    df$title_pos=NULL
    df$body=NULL
    df$body_pos=NULL
  }else if(source=="title"){
    df$txt = df$title
    df$pos=df$title_pos
    df$title = NULL
    df$title_pos = NULL
    df$body = NULL
    df$body_pos=NULL
  }else if(source=="body"){
    df$txt = df$body
    df$pos = df$body_pos
    df$body = NULL
    df$body_pos=NULL
    df$title = NULL
    df$title_pos=NULL
  }
  
  # how -> full den ganzen post nehmen
  if(how=="full"){
    df$how=NULL
    df$how_pos=NULL
  }else if(how=="short"){
    # do not remove anything ???
    df$full= df$txt
    df$full_pos= df$pos
    df$txt=df$how
    df$pos=df$how_pos
    df$how=NULL
    df$how_pos=NULL
    df$title=NULL
    df$title_pos = NULL
    df$body=NULL
    df$body_pos=NULL
  }
  
  # type
  if(type=="pos") {
    df$txt = df$pos
    df$pos=NULL
    df$full= df$full_pos
    df$full_pos = NULL
  } else if (type=="txt"){
    df$pos=NULL
    df$full_pos=NULL
  } else if(type=="combi"){
    # do not remove anything 
  }
  #print(paste("source= ", source, ", type=", type, ", how=", how, sep=""))

  #print(names(df))
  if(label=="sl" && binary == FALSE){
    df = filter_multi_label(df)
  }
  
  # remove too small classes
  toRemove=names(which(table(df$reason)<10))
  if(length(toRemove)>0 & validation==F){
    print("Remove too small classes")
    for(rem in toRemove){
      df = df[(df$reason!=rem),]
    }
  }
 
  
  tbl = df
  tbl$reason = as.factor(tbl$reason)
  tbl$reason = factor(tbl$reason)
  return(tbl)
  
}

get_train_test_dtms <- function(train, train_txt, test, test_txt, sw, ngram, prune, resample_, binary=F, validation=F){
  
  
  
  # TRAININGS SET
  # stemming and stopwords
  train_tokens = get_tokens(train_txt, sw)
  it_train = itoken(train_tokens, ids = train$id, progressbar = FALSE)  # turn off progressbar because it won't look nice in rmd
  
  # ngrams
  if(ngram > 1){
    vocab = create_vocabulary(it_train, ngram = c(ngram_min = ngram, ngram_max = ngram))
  }else{
    vocab = create_vocabulary(it_train)
  } 
  
  # prune vocabulary
  if(prune){
    vocab = prune_vocabulary(vocab, term_count_min = 1, doc_proportion_max = 0.8)
  }
 
  vec = vocab_vectorizer(vocab)
  
  dtm_train  = create_dtm(it_train, vec)
  
  train.DTM = as.data.frame(as.matrix(dtm_train))
  train.DTM$label = train$reason
  train.DTM$label = as.factor(train.DTM$label)
  
  # resampling 
  if(resample_=="smote"){
    if(binary){
      train.DTM = resampling_binary(train.DTM)
    }else{
      train.DTM = resampling_multi(train.DTM)
    }
  } 
  retlist = list("dtm_train"=train.DTM,"train"=train)
  
  # TEST SET
  if(length(test) > 0){
    test_tokens = get_tokens(test_txt, sw)
    it_test = itoken(test_tokens, ids = test$id, progressbar = FALSE)  
    dtm_test  = create_dtm(it_test, vec)
    test.DTM = as.data.frame(as.matrix(dtm_test))
    retlist = list("dtm_train"=train.DTM,"train"=train , "dtm_test"=test.DTM, "test"=test)
  }
 
  return(retlist)
}

get_train_test_dtms_combi <- function(train, test, sw, ngrams, prune, resample, binary=F, how, validation=F){
  
  
  
  if(validation==F){
    if(how=="short"){
      list_txt = get_train_test_dtms(train, train$txt, test, test$full, sw, ngrams$txt, prune, "none")
      list_pos = get_train_test_dtms(train, train$pos, test, test$full_pos, "none", ngrams$pos, prune, "none")
    }else{
      list_txt = get_train_test_dtms(train, train$txt, test, test$txt, sw, ngrams$txt, prune, "none")
      list_pos = get_train_test_dtms(train, train$pos, test, test$pos, "none", ngrams$pos, prune, "none")
    }
  }else{
    if(how=="short"){
      list_txt = get_train_test_dtms(train, train$txt, test, test$txt, sw, ngrams$txt, prune, "none")
      list_pos = get_train_test_dtms(train, train$pos, test, test$pos, "none", ngrams$pos, prune, "none")
    }else{
      list_txt = get_train_test_dtms(train, train$txt, test, test$txt, sw, ngrams$txt, prune, "none")
      list_pos = get_train_test_dtms(train, train$pos, test, test$pos, "none", ngrams$pos, prune, "none")
    }
  }
  
  
  # train
  train.DTM = cbind(list_txt$dtm_train, list_pos$dtm_train, make.row.names=T)
  train.DTM$label = NULL
  train.DTM$label = NULL
  train.DTM$label = as.factor(list_txt$train$reason)
  
  # test
  test.DTM = cbind(list_txt$dtm_test, list_pos$dtm_test, make.row.names=T)
  test.DTM$label = NULL
  test.DTM$label = NULL
  test.DTM$label = as.factor(list_txt$test$reason)

  
  # resampling 
  if(resample=="smote"){
   # print("apply SMOTE")
    if(binary){
      train.DTM = resampling_binary(train.DTM)
      
      
    }else{
      train.DTM = resampling_multi(train.DTM)
    }
  } 

  retlist = list("dtm_train"=train.DTM,"train"=train , "dtm_test"=test.DTM, "test"=test)
  
  
  return(retlist)
}

apply_stratified_sampling_binary_full <- function(data_in, name){

  #data = df[,1:3]
  data = data_in
  data$cat = F
  data[data$reason==name,]$cat=T
  data$reason=NULL
  
  cat = unique(data[data$cat ==T,])
  notCat = unique(data[!data$id %in% cat$id, ])
  
  data = rbind(cat, notCat)
  data$reason = as.factor(data$cat)
  data$cat = NULL
  
  # cat
  ssize = max(1,floor(distr*(dim(cat)[1]))) 
  cat_ids = sample(cat$id,ssize)
  
  # notCat
  ssize = max(1,floor(distr*(dim(notCat)[1])))
  notCat_ids = sample(notCat$id,ssize)
  
  train_ids = c(cat_ids, notCat_ids)
  
  train = data[data$id %in% train_ids,]
  test = data[!data$id %in% train_ids,]
  #print(table(train$reason))
  #print(table(test$reason))
  
  return(list("train"=train, "test"=test))
}


apply_stratified_sampling_binary_short <- function(data_in, name){
  #data = df[,c(1,2,5,3)]
  data = data_in
  data$cat = F
  data[data$reason==name,]$cat=T
  data$reason=NULL
  
  cat = data[data$cat ==T,]
  notCat = data[!data$id %in% cat$id, ]
  
  data = rbind(cat, notCat)
  data$reason = as.factor(data$cat)
  data$cat = NULL
  
  len_cat = length(unique(cat$id))
  
  len_notCat = length(unique(notCat$id))
  
  # cat - id
  ssize = max(1,floor(distr*(len_cat))) 
  cat_ids = sample(unique(cat$id),ssize)
 
  # notCat - id
  ssize = max(1,floor(distr*(len_notCat)))
  notCat_ids = sample(unique(notCat$id),ssize)

  train_ids = c(cat_ids, notCat_ids)
  
  train = data[data$id %in% train_ids,]
  test = data[!data$id %in% train_ids,]
  
  return(list("train"=train, "test"=test))
}
  
  
apply_stratified_sampling <- function(data,name, binary, how){
  if(binary==T && how == "full"){
    return(apply_stratified_sampling_binary_full(data, name))
  } else if(binary ==T && how =="short"){
    return(apply_stratified_sampling_binary_short(data, name))
  } else{
    print("this should not happen")
  }
}

get_tokens <- function(txt, sw.custom){
  if(sw.custom =="none"){
    #dirty hack
    tokens = tokenize_word_stems(txt)
    
  }else{
    sw = stopwords("en")
    if(sw.custom=="custom"){
      sw = sw[-c(which(sw=="but"), which(sw=="no"), which(sw=="not"), which(sw=="to"))]
    }
    tokens = tokenize_word_stems(txt, stopwords = sw)
  }
  return(tokens)
}


filter_multi_label <- function(df){
 #print(">> filter multi-labelled instances")
  t = table(df$id)
  ids1 = names(t[t==1])
  ids = names(t[t>1]) # already unique
 
  df_ret = df[df$id %in% ids1,]

  for(id in ids){
    data = df[df$id==id,]
    tr = table(data$reason)
    tm = max(tr)
    if(length(tr[tr==tm])==1){
      idx_max=which.max(tr)
      reason_neu = names(tr[idx_max])
      df_ret  =  rbind(df_ret, data[data$reason == reason_neu,])
    }
    
  }
  df_ret = unique(df_ret)
  df_ret$reason = as.factor(df_ret$reason)
  
  #table(df_ret$reason)
  

  
  return(df_ret)
}



