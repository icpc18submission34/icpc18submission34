
apply_svm <- function(data, name, run, ngrams, sw, label, tune, prune, resample, binary = F, source, type,how, gamma_=NULL, epsilon=0.1, cost=1){
 
  test = data$test
  train = data$train
  dtm_test = data$dtm_test
  dtm_train = data$dtm_train
  train.label = dtm_train$label
  dtm_train$label=NULL
  dtm_test$label=NULL
  
  setting=list("run"=run, "reason" = name,"ngrams"=ngrams, "sw"=sw, "label"=label, "tune"=tune, "prune"=prune, "resample"=resample)
 
  # tuning: grid search
  if(tune){
    tuned.svm <- tune.svm(x=dtm_train, y=train.label, kernel = "radial", gamma =c(0.001, 0.01, 0.1,0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1), cost=c(0.001, 0.01, 0.1, 0.5, 0.7, 1, 5,10), cross=5)

    reason.svm <-  tuned.svm$best.model
    gamma = reason.svm$gamma
    names(gamma)=gamma
    epsilon = reason.svm$epsilon
    names(epsilon)=epsilon
    cost = reason.svm$cost
    names(cost)=cost

    
    llist = list("res" = cbind(t(setting), gamma, epsilon, cost), "conf"=c("-","-","-","-"))
    return(llist) 
   
  }else{
    if(is.null(gamma_)){
      reason.svm  <- svm(x=dtm_train, y=train.label, probability=T) 
    }else{
      reason.svm  <- svm(x=dtm_train, y=train.label, probability=T, gamma=gamma_, epsilon = epsilon, cost=cost) 
    }
   
    
    predictions=predict(reason.svm, dtm_test)
    probs=predict(reason.svm, dtm_test, probability=TRUE)
    probs=attr(probs, "probabilities")
    
    # metrics
    mm = get_metrics(predictions, test$reason, probs)
    metrics = mm$metrics
    conf = mm$conf
    
  
    return(list("res" = cbind(setting, metrics), "conf"=conf))
  }
}