library(text2vec)
library(data.table)
library(tokenizers)
library(randomForest)
library(caret)
library(pROC)
library(ROCR)
library(e1071)
library(SparseM)
library(doMC)
library(foreach)
library(plyr)
library(psych)


setwd("path/to/here")

source("resampling.R")
source("rf.R")
source("svm.R")
source("preprocessor.R")

# SETTINGS
registerDoMC(4)
filename="posts.csv"


source=c("all")
distr<<-0.9 
do_imps<--F
binary=T
runs = 2

# SETTINGS

start <- function(){

  # save ane compare best settings:
  summary = save_results_summaries("res/","20/") # mean over 20 runs for each setting
  settings_rf_how = return_best_settings(T)$RF
  settings_svm_how = return_best_settings(T)$SVM
  

  
  # RF
  res100_rf = run_rf("settings_RF.csv")
  
  # TUNE
  # run if you want to try tuning
  #tune_settings_rf("settings_RF.csv")
  #res100_rf = run_rf("tuned_settings_RF.csv")

}



run_rf <- function(fn){
    settings_RF =fread(fn)
    tune=F
    setRF = data.frame()
    #setRF = foreach(i=seq(1,nrow(settings_RF)),.combine = rbind.fill) %dopar% {  
    for(i in seq(1,nrow(settings_RF))){
      cat = settings_RF[i,]
      print(cat$reason)
      ngrams = list("ngrams" =cat$ngrams, "ngrams.txt"=cat$ngrams.txt, "ngrams.pos"=cat$ngrams.pos)
      fn = paste("res/100/RF_",cat$reason, ".csv", sep="")
      res =  run_mla_select(runs,"RF", cat$type, cat$how,fn, binary, cat$reason, ngrams, cat$sw, cat$label, tune, cat$prune, cat$resample, ntree=cat$ntree)
      setRF = rbind.fill(setRF, res)
      #return(res)
    }
}





tune_settings_rf <- function(fn){
  print("tune settings for Random Forest")
  tune<-T
  tune_runs<-100
  settings = fread(fn)
  setRF = settings 
  # setRF = settings[1:2,]
  setRF$tune=NULL
  setRF_tuned = data.frame()
  # TUNE
  for(i in seq(1,nrow(setRF))){
  #setRF_tuned = foreach(i=seq(1,nrow(setRF)),.combine = rbind.fill) %dopar% {
    cat = setRF[i,]
    print(cat$reason)
    ngrams = list("ngrams" =cat$ngrams, "ngrams.txt"=cat$ngrams.txt, "ngrams.pos"=cat$ngrams.pos)
    res =  run_mla_select(tune_runs,"RF", cat$type, cat$how, "tunefile", binary, cat$reason, ngrams, cat$sw, cat$label, tune, cat$prune, cat$resample)
    setRF_tuned = rbind.fill(setRF_tuned, res)
  # return(res)
  }

  setRF_tuned =  setRF_tuned[,c(which(colnames(setRF_tuned)=="reason"), which(colnames(setRF_tuned)=="ntree"))]
  setRF_tuned_mean = aggregate(ntree ~ reason, FUN=mean, data=setRF_tuned)
  setRF_tuned_mean=  merge(setRF,setRF_tuned_mean, by=c("reason"))
  setRF_tuned_mean$ntree = floor(setRF_tuned_mean$ntree)
  
  setRF_tuned_mean$tune=T
  fwrite(setRF_tuned_mean, "tuned_settings_RF.csv")
  

  setRF_tuned=  merge(setRF,setRF_tuned, by=c("reason"))
  setRF_tuned$tune=T
  fwrite(setRF_tuned, "tuned_settings_all_RF.csv")
}



print_results <- function(results){
  summ = data.frame()
  names_ = names(results)
    if("reason" %in% names_){
      if("ngrams.txt" %in% names_ && "ngrams.pos" %in% names_){
        print("COMBI - BINARY")
        summ = aggregate(acc ~ source + type + how + reason + ngrams.txt + ngrams.pos + sw + label + tune + prune + resample, FUN = mean, data=results,na.action=na.pass, na.rm=TRUE)
        summ$prec_t = aggregate(prec_t ~ source + type + how + reason + ngrams.txt + ngrams.pos + sw + label + tune + prune + resample, FUN = mean, data=results,na.action=na.pass, na.rm=TRUE)$prec
        summ$rec_t = aggregate(rec_t ~ source + type + how + reason + ngrams.txt + ngrams.pos + sw + label + tune + prune + resample, FUN = mean, data=results,na.action=na.pass, na.rm=TRUE)$rec
        summ$f_t = aggregate(f_t ~ source + type + how + reason + ngrams.txt + ngrams.pos + sw + label + tune + prune + resample, FUN = mean, data=results,na.action=na.pass, na.rm=TRUE)$f
        summ$auc = aggregate(auc ~ source + type + how + reason + ngrams.txt + ngrams.pos + sw + label + tune + prune + resample, FUN = mean, data=results,na.action=na.pass, na.rm=TRUE)$auc
        summ$prec_f = aggregate(prec_f ~ source + type + how + reason + ngrams.txt + ngrams.pos + sw + label + tune + prune + resample, FUN = mean, data=results,na.action=na.pass, na.rm=TRUE)$prec
        summ$rec_f = aggregate(rec_f ~ source + type + how + reason + ngrams.txt + ngrams.pos + sw + label + tune + prune + resample, FUN = mean, data=results,na.action=na.pass, na.rm=TRUE)$rec
        summ$f_f = aggregate(f_f ~ source + type + how + reason + ngrams.txt + ngrams.pos + sw + label + tune + prune + resample, FUN = mean, data=results,na.action=na.pass, na.rm=TRUE)$f
        summ$prec_avg = aggregate(prec_avg ~ source + type + how + reason + ngrams.txt + ngrams.pos + sw + label + tune + prune + resample, FUN = mean, data=results,na.action=na.pass, na.rm=TRUE)$prec
        summ$rec_avg = aggregate(rec_avg ~ source + type + how + reason + ngrams.txt + ngrams.pos + sw + label + tune + prune + resample, FUN = mean, data=results,na.action=na.pass, na.rm=TRUE)$rec
        summ$f_avg = aggregate(f_avg ~ source + type + how + reason + ngrams.txt + ngrams.pos + sw + label + tune + prune + resample, FUN = mean, data=results,na.action=na.pass, na.rm=TRUE)$f
        
        
        } else{
        print("normal - BINARY")
        summ = aggregate(acc ~ source + type + how + reason + ngrams + sw + label + tune + prune + resample, FUN = mean, data=results,na.action=na.pass, na.rm=TRUE)
        summ$prec_t = aggregate(prec_t ~  source + type + how + reason + ngrams + sw + label + tune + prune + resample, FUN = mean, data=results,na.action=na.pass, na.rm=TRUE)$prec
        summ$rec_t = aggregate(rec_t ~  source + type + how + reason + ngrams + sw + label + tune + prune + resample, FUN = mean, data=results,na.action=na.pass, na.rm=TRUE)$rec
        summ$f_t = aggregate(f_t ~  source + type + how + reason + ngrams + sw + label + tune + prune + resample, FUN = mean, data=results,na.action=na.pass, na.rm=TRUE)$f
        summ$auc = aggregate(auc  ~ source + type + how + reason + ngrams + sw + label + tune + prune + resample, FUN = mean, data=results,na.action=na.pass, na.rm=TRUE)$auc
        summ$prec_f = aggregate(prec_f ~  source + type + how + reason + ngrams + sw + label + tune + prune + resample, FUN = mean, data=results,na.action=na.pass, na.rm=TRUE)$prec
        summ$rec_f = aggregate(rec_f ~  source + type + how + reason + ngrams + sw + label + tune + prune + resample, FUN = mean, data=results,na.action=na.pass, na.rm=TRUE)$rec
        summ$f_f = aggregate(f_f ~  source + type + how + reason + ngrams + sw + label + tune + prune + resample, FUN = mean, data=results,na.action=na.pass, na.rm=TRUE)$f
        summ$prec_avg = aggregate(prec_avg ~  source + type + how + reason + ngrams + sw + label + tune + prune + resample, FUN = mean, data=results,na.action=na.pass, na.rm=TRUE)$prec
        summ$rec_avg = aggregate(rec_avg ~  source + type + how + reason + ngrams + sw + label + tune + prune + resample, FUN = mean, data=results,na.action=na.pass, na.rm=TRUE)$rec
        summ$f_avg = aggregate(f_avg ~  source + type + how + reason + ngrams + sw + label + tune + prune + resample, FUN = mean, data=results,na.action=na.pass, na.rm=TRUE)$f
        
        
        }
    }else {
      if("ngrams.txt" %in% names_ && "ngrams.pos" %in% names_){
        print("COMBI - MULTI-CLASS")
        summ = aggregate(acc ~ ngrams.txt + ngrams.pos + sw + label + tune + prune + resample, FUN = median, data=results)
        summ$prec = aggregate(prec ~  ngrams.txt + ngrams.pos + sw + label + tune + prune + resample, FUN = median, data=results)$prec
        summ$rec = aggregate(rec ~  ngrams.txt + ngrams.pos + sw + label + tune + prune + resample, FUN = median, data=results)$rec
        summ$f = aggregate(f ~  ngrams.txt + ngrams.pos + sw + label + tune + prune + resample, FUN = median, data=results)$f
        summ$auc = aggregate(auc ~  ngrams.txt + ngrams.pos + sw + label + tune + prune + resample, FUN = median, data=results)$auc
      } else{
        print("MULTI-CLASS")
        summ = aggregate(acc ~ ngrams + sw + label + tune + prune + resample, FUN = median, data=results)
        summ$prec = aggregate(prec ~ ngrams + sw + label + tune + prune + resample, FUN = median, data=results)$prec
        summ$rec = aggregate(rec ~ ngrams + sw + label + tune + prune + resample, FUN = median, data=results)$rec
        summ$f = aggregate(f ~ ngrams + sw + label + tune + prune + resample, FUN = median, data=results)$f
        summ$auc = aggregate(auc ~ ngrams + sw + label + tune + prune + resample, FUN = median, data=results)$auc
      }
    }
  
  return(summ)
  
}

return_best_settings <- function(how=F){
  
  categories = c("api_change", "api_usage", "conceptual", "discrepancy", "documentation", "errors", "review")
  ml = c("RF", "SVM")
  settings_RF = data.frame()
  settings_RF_short = data.frame()
  settings_RF_full = data.frame()
  settings_SVM = data.frame()
  settings_SVM_short = data.frame()
  settings_SVM_full = data.frame()
  #names(settings) = c("source","type","how","reason","ngrams.txt","ngrams.pos",   "sw", "label",  "tune", "prune","resample","acc","prec","rec", "f","auc","ngrams")
  
  for(cat in categories){
    
     fn =  list.files("sum/20/", pattern=paste("*","sum_",cat, ".csv", sep=""), full.names = FALSE)
     #print(fn)
     summary_RF = fread(paste("sum/20/",fn[1], sep=""))
     #print(summary_RF[summary_RF$f == max(summary_RF$f),])
     data = return_max_auc(summary_RF[summary_RF$f_avg == max(summary_RF$f_avg),])
     settings_RF = rbind(settings_RF,data)

     summary_SVM= fread(paste("sum/20/",fn[2], sep=""))
     summary_SVM[is.na(summary_SVM)]=0
     #print(summary_SVM[summary_SVM$f == max(summary_SVM$f),])
     data = return_max_auc(summary_SVM[summary_SVM$f_avg == max(summary_SVM$f_avg),])
     settings_SVM = rbind(settings_SVM,data)
     
     if(how){
       #rf
       summary_RF_full = summary_RF[summary_RF$how=="full",]
       data = return_max_auc(summary_RF_full[summary_RF_full$f_avg == max(summary_RF_full$f_avg),])
       settings_RF_full = rbind(settings_RF_full,data)
       
       summary_RF_short = summary_RF[summary_RF$how=="short",]
       data = return_max_auc(summary_RF_short[summary_RF_short$f_avg == max(summary_RF_short$f_avg),])
       settings_RF_short = rbind(settings_RF_short,data)
       #svm
       summary_SVM_full = summary_SVM[summary_SVM$how=="full",]
       data = return_max_auc(summary_SVM_full[summary_SVM_full$f_avg == max(summary_SVM_full$f_avg),])
       settings_SVM_full = rbind(settings_SVM_full,data)
       
       summary_SVM_short = summary_SVM[summary_SVM$how=="short",]
       data = return_max_auc(summary_SVM_short[summary_SVM_short$f_avg == max(summary_SVM_short$f_avg),])
       settings_SVM_short = rbind(settings_SVM_short,data)
     }
     
     
  }

  if(how){
    # save rf
    fwrite(settings_RF_full, "settings_RF_full.csv")
    fwrite(settings_RF_short, "settings_RF.csv")
     # save svm 
    fwrite(settings_SVM_full, "settings_SVM_full.csv")
    fwrite(settings_SVM_short, "settings_SVM.csv")
    
    #settings_RF = settings_RF_short
    settings_RF = rbind.fill(settings_RF_full, settings_RF_short)
    settings_SVM = rbind.fill(settings_SVM_full, settings_SVM_short)
  }
  return(list("RF"=settings_RF, "SVM"=settings_SVM))
  
  
}

save_results_summaries <- function(path1="res/", path2="20/", tuned=""){
  path=paste(path1, path2, sep="")
  sumpath= paste("sum/",path2,sep="")

  if(path2=="20/"){
    sum.rf = generate_data_summary_for_all_cat("rf", path, sumpath)
    sum.svm = generate_data_summary_for_all_cat("svm", path,sumpath)

  }else{
    sum.rf = generate_data_summary_for_ML("rf", path, tuned)
    sum.svm = generate_data_summary_for_ML("svm", path, tuned)
  }
  
  
  return(list("RF"=sum.rf, "SVM"=sum.svm))
} 
 

return_max_auc <- function(data){
  return(data[data$auc == max(data$auc)])
}

generate_data_summary_for_all_cat <- function (ML, path="res/20/", sumpath="sum/20"){
  print(paste(">> generate data summary for ",ML, sep=""))
  
  filenames = list.files(path, pattern=paste(ML,"*", sep=""), full.names = FALSE)
  
  res_api_usage= data.frame()
  res_api_change = data.frame()
  res_conceptual = data.frame()
  res_discrepancy = data.frame()
  res_documentation = data.frame()
  res_errors = data.frame()
  res_review = data.frame()
  
  
  for (fn in filenames){
    #print(fn)
    results.df <- fread(paste(path,fn, sep=""))
    results_na = as.data.frame(results.df)
    results_na[is.na(results_na)] = 0
    if(dim(results_na)[1]==0){
      print(paste("after removal of NAs no data left ---> skip ", fn, sep=""))
    } else{
      
      res_sum = print_results(results_na)

      res_api_usage = rbind.fill(res_api_usage, res_sum[res_sum$reason == "API_USAGE",])
      res_api_change = rbind.fill(res_api_change, res_sum[res_sum$reason == "API_CHANGE",])
      res_conceptual = rbind.fill(res_conceptual, res_sum[res_sum$reason == "CONCEPTUAL",])
      res_discrepancy = rbind.fill(res_discrepancy, res_sum[res_sum$reason == "DISCREPANCY",])
      res_documentation = rbind.fill(res_documentation, res_sum[res_sum$reason == "DOCUMENTATION",])
      res_errors = rbind.fill(res_errors, res_sum[res_sum$reason == "ERRORS",])
      res_review = rbind.fill(res_review, res_sum[res_sum$reason == "REVIEW",])
      
      
    }
  }
  if(length(filenames)>0){
    fwrite(res_api_usage, paste(sumpath,ML, "_sum_api_usage.csv", sep=""))
    fwrite(res_api_change, paste(sumpath,ML, "_sum_api_change.csv", sep=""))
    fwrite(res_conceptual, paste(sumpath,ML, "_sum_conceptual.csv", sep=""))
    fwrite(res_discrepancy, paste(sumpath,ML, "_sum_discrepancy.csv", sep=""))
    fwrite(res_documentation, paste(sumpath,ML, "_sum_documentation.csv", sep=""))
    fwrite(res_errors, paste(sumpath,ML, "_sum_errors.csv", sep=""))
    fwrite(res_review, paste(sumpath,ML, "_sum_review.csv", sep=""))
  }
  return(list("api_usage"= res_api_usage, "api_change"=res_api_change, "conceptual"=res_conceptual, "discprepancy"=res_discrepancy, "documentation"=res_documentation, "errors"=res_errors, "review"=res_review))
}

generate_data_summary_for_ML <- function (ML, path="res/100/", tuned=""){
  print(paste(">> generate data summary for ",ML, sep=""))
  
  res_sum = data.frame()
  filenames = list.files(path, pattern=paste("100_",ML,"*", sep=""), full.names = FALSE)

  for (fn in filenames){
    #print(fn)
    results.df <- fread(paste(path,fn, sep=""))
    results_na = as.data.frame(results.df)
    # results.na = results.df
    results_na[is.na(results_na)] = 0
    #results_na =    results.df[is.na(results.df$prec)==F & is.na(results.df$rec)==F & is.na(results.df$f)==F,]
    if(dim(results_na)[1]==0){
      print(paste("after removal of NAs no data left ---> skip ", fn, sep=""))
    } else{
      
      res = print_results(results_na)
      res_sum = rbind.fill(res_sum, res)
    }
  }
  if(nrow(res_sum)>0){
    ffn = paste("sum/100_",ML,tuned, "_sum.csv", sep="")
    fwrite(res_sum,ffn )
    print(paste("summary saved into ", ffn, sep=""))
  }
  return(res_sum)
  }

run_mla_select <- function(runs, MLA, type, how, fn, binary, category, ngrams, sw, label, tune, prune, resample, ntree=NULL, gamma=NULL, epsilon=NULL, cost=NULL){
  
  fn = paste(fn, "_",source,  ".csv", sep="")
    if(file.exists(fn)){
      file.remove(fn)
    }
    if(tune){
      fn = paste("tune_to_remove.csv", sep="")
    }
    
    rf = data.frame()
    header = ""
   if(type=="combi"){
      print(paste("> BINARY > reason=",category, ", source= ", source, ", type= ", type, ", how= ", how, ", ngram_txt= ", ngrams$ngrams.txt, ", ngram_pos= ", ngrams$ngrams.pos, ", sw= ", sw, ", label= ", label, ", tune= ", tune, ", prune= ", prune, ", resample= ", resample, sep=""))                      
      res = apply_mla_binary(runs,MLA, source, type, how, list("txt"=ngrams$ngrams.txt, "pos"=ngrams$ngrams.pos), sw, label, tune, prune, resample, category, ntree, gamma, epsilon, cost)
      res = cbind("source"=source, "type"=type, "how"=how, res)
      rf = rbind.fill(rf, res )
      #fwrite(res, fn, append = T,row.names=T, col.names=F)
      if(!tune){
        write.table(res, fn, append=TRUE, sep=",", row.names=F, col.names = T)
      }
      header = names(res)
      
    }else{
      print(paste("> BINARY > reason=",category, ", source= ", source, ", type= ", type, ", how= ", how, ", ngram= ", ngrams$ngrams, ", sw= ", sw, ", label= ", label, ", tune= ", tune, ", prune= ", prune, ", resample= ", resample, sep=""))
      res = apply_mla_binary(runs,MLA, source, type, how, ngrams$ngrams, sw, label, tune, prune,resample, category, ntree,gamma, epsilon, cost)
      res = cbind("source"=source, "type"=type, "how"=how, res)
      rf = rbind.fill(rf,res )
      if(!tune){
        fwrite(res, fn, append = T,row.names=F, col.names=T)
      }
      #write.table(res, fn, append=TRUE, sep=",", row.names=T, col.names = F)
      header = names(res)
    }
   
  return(rf)
}

get_metrics <- function(predictions, reason_, probs){
  positive = NULL
  positive="TRUE"
    
  matrix_t = confusionMatrix(predictions, reason_, "TRUE")
  #print(matrix_t$table)
    
  conf=matrix_t$table
  prec_t = matrix_t$byClass[5]
  rec_t = matrix_t$byClass[6]
  
  if(is.na(prec_t)){
    prec_t=0
  }
  if(is.na(rec_t)){
    rec_t=0
  }
  f1_t = matrix_t$byClass[7]
    
  if(prec_t==0 & rec_t==0){
    f1_t = 0
  }
  
  matrix_f = confusionMatrix(predictions, reason_, "FALSE")
  prec_f = matrix_f$byClass[5]
  rec_f = matrix_f$byClass[6]
  
  if(is.na(prec_f)){
    prec_f=0
  }
  if(is.na(rec_f)){
    rec_f=0
  }
  f1_f = matrix_f$byClass[7] #2*prec_f*rec_f/(prec_f+rec_f)
  
  if(prec_f==0 & rec_f==0){
    f1_f = 0
  }
    
  anz_f = table(reason_)[1]
  anz_t = table(reason_)[2]
    
  prec_avg  = (prec_t *anz_t  + prec_f * anz_f ) / (anz_t+anz_f)
  rec_avg  = (rec_t *anz_t  + rec_f * anz_f ) / (anz_t+anz_f)
  f_avg  = (f1_t *anz_t  + f1_f * anz_f ) / (anz_t+anz_f)
    
  acc = matrix_t$overall[1]
  auc <- roc(reason_, probs[,2], levels=c("TRUE", "FALSE"))$auc
    
  metrics=data.frame(acc=acc,prec_t=prec_t,rec_t=rec_t,f_t=f1_t,prec_f=prec_f,rec_f=rec_f,f_f=f1_f,prec_avg=prec_avg, rec_avg=rec_avg, f_avg=f_avg,auc=auc)
  rownames(metrics)=""
  
  return(list("metrics"=metrics, "conf"=conf))

}

apply_mla_binary <- function(runs,MLA, source, type,how, ngrams, sw, label, tune, prune, resample, category, ntree=NULL, gamma=NULL, epsilon=NULL, cost=NULL){
  #binary = T
  tmpResults = data.frame()
  
  #for(i in seq(1:runs)){
  tmpResults = foreach(i=1:runs,.combine = rbind) %dopar% {  
    #print(i)
    retList = data.frame()
    impsList = data.frame()
    data=preprocess_data(source, type, how, label, binary)
    names_ = names(table(data$reason))
    #tbl = as.data.frame.matrix(table(data))
    
    if(is.null(category)==F){
      names_ = category
    }
     for( name in names_ ){
      #print(name)
      data_set = apply_stratified_sampling(data,name, binary, how)
      
      test = data_set$test
      train = data_set$train
      
      # make test set unique
      test_unique=data.frame()
      for(id in unique(test$id)){
        test_unique = rbind(test_unique,test[test$id == id,][1,])
      }
      test = test_unique
      
      # data sanity check
      if(type=="combi"){
        data_ = get_train_test_dtms_combi(train, test, sw, ngrams, prune, resample, binary, how)
      } else{
        if(how=="short"){
          data_ = get_train_test_dtms(train, train$txt, test, test$full, sw, ngrams, prune, resample, binary)
        } else{
          data_ = get_train_test_dtms(train, train$txt, test, test$txt, sw, ngrams, prune, resample, binary)
        }
      }
      
      
      if(MLA=="RF"){
        rf.res = apply_random_forest(data_, name,i, ngrams, sw, label, tune, prune, resample,binary, source, type,how, ntree)
        rlist = rf.res$res
        conf = rf.res$conf
        if(do_imps==T){
          impsList = rbind.fill(impsList, rf.res$imps)
        }
        
        #print(conf)
      } else if (MLA =="SVM"){
        svm.res = apply_svm(data_, name,i, ngrams, sw, label, tune, prune, resample,binary, source, type,how,gamma, epsilon, cost)
        rlist = svm.res$res
        conf = svm.res$conf
        # print(conf)
      }
      rlist = cbind(rlist, "TN"=conf[1], "FP" = conf[2], "FN" = conf[3], "TP" = conf[4])
      retList = rbind(retList,rlist )
    }
    
    if(do_imps==T){
      retList = cbind(retList, impsList)
    }
    return(retList)
    #tmpResults = rbind.fill(tmpResults, retList)
  }
  return(tmpResults)
}

#start()